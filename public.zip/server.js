import express from "express";
import cors from "cors";
import axios from "axios";

const app = express();

app.use(cors());

const STOCKS = [
  "RELIANCE.NS",
  "TCS.NS",
  "INFY.NS",
  "HDFCBANK.NS",
  "WIPRO.NS",
  "TATASTEEL.NS",
  "HCLTECH.NS",
  "SBIN.NS",
  "HINDUNILVR.NS",
  "ITC.NS",
  "LT.NS",
  "BAJFINANCE.NS",
  "KOTAKBANK.NS",
  "AXISBANK.NS",
  "ASIANPAINT.NS",
  "^NSEI",
  "^BSESN"
];

// Cache
let cache = {
  data: null,
  timestamp: null,
};

// Fetch one stock safely
const fetchStock = async (symbol) => {
  try {
    const url =
      `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}` +
      `?range=7d&interval=1d`;

    const response = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
      },

      timeout: 10000,
    });

    const result =
      response.data?.chart?.result?.[0];

    if (!result) {
      return null;
    }

    const closes =
      result.indicators?.quote?.[0]
        ?.close || [];

    const validCloses = closes.filter(
      (price) => price !== null
    );

    if (validCloses.length < 2) {
      return null;
    }

    const currentPrice =
      validCloses[
        validCloses.length - 1
      ];

    const previousPrice =
      validCloses[
        validCloses.length - 2
      ];

    const changePercent =
      ((currentPrice -
        previousPrice) /
        previousPrice) *
      100;

    return {
      symbol,
      shortSymbol:
        symbol.replace(".NS", ""),

      price: currentPrice,

      change: changePercent,

      chart: response.data,
    };
  } catch (error) {
    console.log(
      `Failed: ${symbol}`,
      error.message
    );

    return null;
  }
};

//
// ✅ FETCH ALL STOCKS
//
app.get("/api/stocks", async (req, res) => {
  try {
    const now = Date.now();

    // Cache 60 sec
    if (
      cache.data &&
      now - cache.timestamp < 60000
    ) {
      console.log(
        "Serving stocks from cache"
      );

      return res.json(cache.data);
    }

    console.log(
      "Fetching fresh stock data..."
    );

    const stockData =
      await Promise.all(
        STOCKS.map(fetchStock)
      );

    const filtered =
      stockData.filter(Boolean);

    cache = {
      data: filtered,
      timestamp: now,
    };

    res.json(filtered);
  } catch (error) {
    console.error(error.message);

    res.status(500).json({
      error:
        "Failed to fetch stock market data",
    });
  }
});

//
// ✅ FETCH SINGLE STOCK CHART
//
app.get(
  "/api/chart/:symbol",
  async (req, res) => {
    try {
      const { symbol } = req.params;
      const range = req.query.range || "7d";
      const interval = req.query.interval || "1d";

      const url =
        `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}` +
        `?range=${range}&interval=${interval}`;

      const response =
        await axios.get(url, {
          headers: {
            "User-Agent":
              "Mozilla/5.0",
          },

          timeout: 10000,
        });

      res.json(response.data);
    } catch (error) {
      console.error(`Failed to fetch chart data for ${req.params.symbol}:`, error.message);

      res.status(500).json({
        error:
          "Failed to fetch chart data",
      });
    }
  }
);

app.listen(5000, () => {
  console.log(
    "✅ Strong backend running on port 5000"
  );
});