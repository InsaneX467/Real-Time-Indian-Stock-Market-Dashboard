import 'bootstrap/dist/css/bootstrap.min.css'
import './index.css'
import ReactDOM from "react-dom/client";
import App from './App.jsx'
import "./pages/dashboard.css"

ReactDOM.createRoot(document.getElementById('root')).render(
    <App />
)
