const StockCard = ({ stock }) => {
  return (
    <div className="stock-card">
      <h4>{stock.symbol}</h4>

      <h5>
        ₹{Number(stock.price).toFixed(2)}
      </h5>

      <p
        className={
          stock.change >= 0
            ? "text-success"
            : "text-danger"
        }
      >
        {stock.change > 0 ? "+" : ""}
        {stock.change >= 0 ? "▲" : "▼"}{" "}
{Math.abs(stock.change).toFixed(2)}%
      </p>
    </div>
  );
};

export default StockCard;