import { useEffect, useState } from "react";
import { getQuote } from "../services/stockApi";

const STRIP_STOCKS = ["^NSEI", "^BSESN", "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ITC.NS"];

const MarketStrip = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchStripData = async () => {
      try {
        const results = await Promise.all(
          STRIP_STOCKS.map(async (symbol) => {
            const quote = await getQuote(symbol);
            let displaySymbol = symbol.replace(".NS", "");
            if (symbol === "^NSEI") displaySymbol = "NIFTY 50";
            if (symbol === "^BSESN") displaySymbol = "SENSEX";

            return {
              symbol: displaySymbol,
              price: quote.c,
              change: quote.dp,
            };
          })
        );
        setData(results);
      } catch (error) {
        console.error("Market Strip Error:", error);
      }
    };

    fetchStripData();
    const interval = setInterval(fetchStripData, 60000);
    return () => clearInterval(interval);
  }, []);

  if (data.length === 0) return null;

  return (
    <div className="market-strip-container">
      <div className="market-strip-content">
        {/* Double the data array to create a seamless infinite loop effect */}
        {[...data, ...data].map((item, index) => (
          <div className="market-strip-item" key={index}>
            <span>{item.symbol}</span>
            <span>{item.price ? `₹${Number(item.price).toFixed(2)}` : 'Loading...'}</span>
            {item.change !== undefined && (
                <span className={item.change >= 0 ? "text-success" : "text-danger"}>
                  {item.change >= 0 ? "+" : ""}{Number(item.change).toFixed(2)}%
                </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MarketStrip;
