import { useEffect, useState } from "react";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

import { Line } from "react-chartjs-2";

import { getChartData } from "../services/stockApi";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const StockChart = ({ symbol }) => {
  const [chartData, setChartData] = useState(null);
  const [timeRange, setTimeRange] = useState({ label: "1W", range: "7d", interval: "1d" });

  useEffect(() => {
    let intervalId;

    const fetchChart = async () => {
      try {
        const data = await getChartData(symbol, timeRange.range, timeRange.interval);

        if (!data || !data.chart || !data.chart.result) {
          console.error("Invalid API response");
          return;
        }

        const result = data.chart.result[0];

        if (!result) {
          console.error("No chart result found");
          return;
        }


        const timestamps = result.timestamp || [];
        const closes = result.indicators.quote[0].close || [];

        if (!timestamps.length || !closes.length) return;

        const labels = timestamps.map((time) =>
          new Date(time * 1000).toLocaleDateString("en-IN", {
            day: "numeric",
            month: "short",
            year: timeRange.label === "1Y" ? "2-digit" : undefined
          })
        );

      const firstPrice = closes[0];
      const lastPrice = closes[closes.length - 1];
      const isUp = lastPrice >= firstPrice;

      const strokeColor = isUp ? "var(--success-color)" : "var(--danger-color)";
      const fillColor = isUp ? "var(--success-bg)" : "var(--danger-bg)";

      setChartData({
        labels,
        datasets: [
          {
            label: `${symbol.replace(".NS", "")} Price`,
            data: closes,
            borderColor: strokeColor,
            backgroundColor: fillColor,
            tension: 0.4,
            fill: true,
          },
        ],
      });
      } catch (error) {
        console.error("Chart Error:", error);
      }
    };

    if (symbol) {
      fetchChart();
      intervalId = setInterval(fetchChart, 60000); // ✅ refresh every 60s
    }

    return () => clearInterval(intervalId);
  }, [symbol, timeRange]);

  const ranges = [
    { label: "1W", range: "7d", interval: "1d" },
    { label: "1M", range: "1mo", interval: "1d" },
    { label: "3M", range: "3mo", interval: "1d" },
    { label: "1Y", range: "1y", interval: "1wk" },
  ];

  if (!chartData) {
    return (
      <div className="glass-card chart-card">
        <div className="text-center py-3">
          <div className="spinner-border text-primary"
            role="status">
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card p-4">
      <h3 className="section-title mb-4">
        {symbol.replace(".NS", "")} Trend
        <div className="chart-controls">
          {ranges.map((r) => (
            <button
              key={r.label}
              className={timeRange.label === r.label ? "active" : ""}
              onClick={() => setTimeRange(r)}
            >
              {r.label}
            </button>
          ))}
        </div>
      </h3>

      <Line
        data={chartData}
        options={{
          responsive: true,

          plugins: {
            legend: {
              display: true,
            },

            tooltip: {
              callbacks: {
                label: function (context) {
                  return `₹${context.raw}`;
                },
              },
            },
          },

          scales: {
            y: {
              ticks: {
                callback: function (value) {
                  return `₹${value}`;
                },
              },
            },
          },
        }}
      />
    </div>
  );
};

export default StockChart;