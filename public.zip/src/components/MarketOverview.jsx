import { useEffect, useState } from "react";
import { getQuote } from "../services/stockApi";
import StockCard from "./StockCard";

const stocks = [
  "RELIANCE.NS",
  "TCS.NS",
  "INFY.NS",
  "HDFCBANK.NS",
];

const MarketOverview = ({ setSelectedStock }) => {
  const [marketData, setMarketData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const stockData = await Promise.all(
          stocks.map(async (stock) => {
            const quote = await getQuote(stock);

            return {
              symbol: stock.replace(".NS", ""),
              fullSymbol: stock,
              price: quote.c || 0,
              change: quote.dp || 0,
            };
          })
        );

        setMarketData(stockData);
      } catch (error) {
        console.error("Error fetching stock data:", error);
      }
    };

    fetchData();

    const interval = setInterval(() => {
      fetchData();
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="glass-card p-4">
      <h3 className="section-title">
        Indian Market Overview
      </h3>

      <div className="row flex-nowrap overview-row">
        {marketData.map((stock) => (
          <div
            className="col"
            key={stock.fullSymbol}
            onClick={() =>
              setSelectedStock(stock.fullSymbol)
            }
            style={{ cursor: "pointer" }}
          >
            <StockCard stock={stock} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default MarketOverview;