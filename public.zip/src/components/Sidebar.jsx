import {
  FaChartLine,
  FaList,
  FaNewspaper,
  FaCog,
} from "react-icons/fa";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="logo">STOCKPRO</div>

      <ul className="list-unstyled">
        <li className="active">
          <FaChartLine /> Explore
        </li>

        <li>
          <FaList /> Watchlist
        </li>

        <li>
          <FaNewspaper /> News
        </li>

        <li>
          <FaCog /> Settings
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;