import { useEffect, useState } from "react";
import { getQuote } from "../services/stockApi";

const Watchlist = ({
  watchlist,
  setSelectedStock,
}) => {
  const [stocks, setStocks] = useState([]);

  useEffect(() => {
    const fetchWatchlist = async () => {
      try {
        const data = await Promise.all(
          watchlist.map(async (symbol) => {
            const quote =
              await getQuote(symbol);

            return {
              symbol:
                symbol.replace(".NS", ""),
              fullSymbol: symbol,
              price: quote.c,
              change: quote.dp,
            };
          })
        );

        setStocks(data);
      } catch (error) {
        console.error(
          "Watchlist Error:",
          error
        );
      }
    };

    fetchWatchlist();

    const interval = setInterval(
      fetchWatchlist,
      60000
    );

    return () => clearInterval(interval);
  }, [watchlist]);

  return (
    <div className="glass-card p-4">
      <h3 className="section-title">
        Indian Watchlist
      </h3>
    <div className="watchlist-scroll">
      {stocks.map((stock) => (
        <div
          className="mover-card"
          key={stock.symbol}
          onClick={() =>
            setSelectedStock(
              stock.fullSymbol
            )
          }
          style={{
            cursor: "pointer",
          }}
        >
          <div>
            <strong>
              {stock.symbol}
            </strong>
          </div>

          <div
            style={{
              textAlign: "right",
            }}
          >
            <div>
              ₹
              {Number(
                stock.price
              ).toFixed(2)}
            </div>

            <div
              className={
                stock.change >= 0
                  ? "text-success"
                  : "text-danger"
              }
            >
              {stock.change > 0
                ? "+"
                : ""}
              {Number(
                stock.change
              ).toFixed(2)}
              %
            </div>
          </div>
        </div>
      ))}
      </div>
    </div>
  );
};

export default Watchlist;