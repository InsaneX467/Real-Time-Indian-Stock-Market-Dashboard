import React from 'react';
import { Outlet } from 'react-router-dom';

// NOTE: You will need to import your existing Sidebar and Navbar components.
// The paths below are an assumption. Please adjust them if your files are elsewhere.
import Sidebar from './Sidebar';
import Navbar from './Navbar';

const Layout = () => {
  return (
    <>
      <Sidebar />
      {/* This div is the main content area that sits to the right of the sidebar */}
      <div>
        <Navbar />
        <div className="main-content">
          <Outlet />
        </div>
      </div>
    </>
  );
};

export default Layout;