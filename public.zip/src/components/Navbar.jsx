const Navbar = ({
  searchTerm,
  setSearchTerm,
  handleSearch,
  isDarkMode,
  toggleDarkMode,
}) => {
  return (
    <div className="navbar-custom">
      {/* Left */}
      <div>
        <h3>Market Dashboard</h3>

        <p>
          Track Indian stock market trends
        </p>
      </div>

      {/* Right */}
      <div className="nav-right">
        {/* Search */}
        <div className="search-box">
          <input
            type="text"
            placeholder="Search NSE stock..."
            value={searchTerm}
            onChange={(e) =>
              setSearchTerm(e.target.value)
            }
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSearch();
              }
            }}
          />

          <button onClick={handleSearch}>
            Search
          </button>
        </div>

        {/* Dark Mode Toggle */}
        <button className="theme-toggle-btn" onClick={toggleDarkMode}>
          {isDarkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
        </button>

        {/* Market Status */}
        <div className="market-status">
          Market Closed
        </div>
      </div>
    </div>
  );
};

export default Navbar;