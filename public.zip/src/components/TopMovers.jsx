import { useEffect, useState } from "react";
import { getQuote } from "../services/stockApi";

const stockSymbols = [
  "RELIANCE.NS",
  "TCS.NS",
  "INFY.NS",
  "HDFCBANK.NS",
  "WIPRO.NS",
  "TATASTEEL.NS",
  "HCLTECH.NS",
  "SBIN.NS",
];

const TopMovers = () => {
  const [gainers, setGainers] = useState([]);
  const [losers, setLosers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovers = async () => {
      try {
        const stockData = await Promise.all(
          stockSymbols.map(async (symbol) => {
            const quote = await getQuote(symbol);

            return {
              symbol: symbol.replace(".NS", ""),
              change: quote.dp,
            };
          })
        );

        // Sort descending
        const sorted = [...stockData].sort(
          (a, b) => b.change - a.change
        );

        setGainers(sorted.slice(0, 3));

        setLosers(sorted.slice(-3).reverse());
      } catch (error) {
        console.error("Top Movers Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovers();

    const interval = setInterval(fetchMovers, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="glass-card p-4">
      {loading ? (
        <div className="text-center py-3">
          <div
            className="spinner-border text-primary"
            role="status">
          </div>
    </div>
      ) : (
        <div className="row">
          {/* Gainers */}
          <div className="col-md-6">
            <h3 className="text-success">
              Best Performers
            </h3>

            {gainers.map((gainer) => (
              <div
                className="mover-card"
                key={gainer.symbol}
              >
                <span>{gainer.symbol}</span>

                <span className="text-success">
                  +{Number(gainer.change).toFixed(2)}%
                </span>
              </div>
            ))}
          </div>

          {/* Losers */}
          <div className="col-md-6">
            <h3 className="text-danger">
              Underperforming
            </h3>

            {losers.map((loser) => (
              <div
                className="mover-card"
                key={loser.symbol}
              >
                <span>{loser.symbol}</span>

                <span className="text-danger">
                  {Number(loser.change).toFixed(2)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TopMovers;