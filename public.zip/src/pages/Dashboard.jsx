import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import MarketOverview from "../components/MarketOverview";
import Watchlist from "../components/Watchlist";
import TopMovers from "../components/TopMovers";
import StockChart from "../components/StockChart";
import MarketStrip from "../components/MarketStrip";
import { useState } from "react";

// The expanded list of valid stocks in our backend
const VALID_STOCKS = [
  "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "WIPRO.NS", "TATASTEEL.NS", "HCLTECH.NS", "SBIN.NS",
  "HINDUNILVR.NS", "ITC.NS", "LT.NS", "BAJFINANCE.NS", "KOTAKBANK.NS", "AXISBANK.NS", "ASIANPAINT.NS"
];

const Dashboard = ({ isDarkMode, toggleDarkMode }) => {
  const [activeView, setActiveView] = useState("dashboard");
  const [selectedStock, setSelectedStock] = useState("RELIANCE.NS");
  const [searchTerm, setSearchTerm] = useState("");

  const [watchlist] = useState([
    "RELIANCE.NS",
    "TCS.NS",
    "INFY.NS",
    "HDFCBANK.NS",
    "SBIN.NS",
    "WIPRO.NS",
    "ITC.NS"
  ]);

  const handleSearch = () => {
    if (!searchTerm.trim()) return;

    let formatted = searchTerm.toUpperCase();

    if (!formatted.endsWith(".NS")) {
      formatted += ".NS";
    }

    if (VALID_STOCKS.includes(formatted)) {
      setSelectedStock(formatted);
      setActiveView("dashboard");
      setSearchTerm("");
    } else {
      alert("Results not found for " + searchTerm);
    }
  };

  return (
    <div className="dashboard-wrapper">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div className="main-content">
        <Navbar
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isDarkMode={isDarkMode}
          toggleDarkMode={toggleDarkMode}
        />

        <MarketStrip />

        <div className="container-fluid py-4">
          {activeView === "dashboard" ? (
            <>
              {/* Top Market Overview */}
              <div className="mb-4">
                <MarketOverview
                  setSelectedStock={setSelectedStock}
                />
              </div>

              {/* Chart */}
              <div className="row g-4">
                <div className="col-lg-12">
                  <div className="chart-wrapper">
                    <StockChart symbol={selectedStock} />
                  </div>
                </div>
              </div>

              {/* Movers */}
              <div className="row mt-4">
                <div className="col-lg-12">
                  <TopMovers />
                </div>
              </div>
            </>
          ) : (
             <div className="row">
               <div className="col-lg-12">
                 <Watchlist 
                   watchlist={watchlist} 
                   setSelectedStock={(symbol) => {
                     setSelectedStock(symbol);
                     setActiveView("dashboard");
                   }} 
                 />
               </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;